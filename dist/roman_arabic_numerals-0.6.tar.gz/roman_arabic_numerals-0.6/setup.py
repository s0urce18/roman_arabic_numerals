from setuptools import setup

setup(name='roman_arabic_numerals',
      version='0.6',
      description='Roman numerals converting',
      packages=['roman_arabic_numerals'],
      author_email='boyarkin.gleb@gmail.com',
      zip_safe=False)